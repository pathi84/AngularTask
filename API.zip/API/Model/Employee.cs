﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace angulartask.Model
{
    [Table("Employee")]
    public class Employee
    {
        [Key]
        [Column("Employee ID")]
        public int Id { get; set; }
        [Required]
        [MaxLength(50,ErrorMessage = "Name is too long")]
        [Column("Name")]
        public string Name { get; set; }
        [Column("Job Title")]
        [Required]
        [MaxLength(150, ErrorMessage = "Job Title is too long")]
        public string Title { get; set; }
        [Column("Department")]
        [Required]
        [MaxLength(50, ErrorMessage = "Department is too long")]
        public string Department { get; set; }
        [Column("Country")]
        [Required]
        [MaxLength(20, ErrorMessage = "Country is too long")]
        public string Country { get; set; }
        [Column("Joining Date")]
        public DateTime JoiningDate { get; set; }
        [Column("Gender")]
        [Required]
        [MaxLength(10, ErrorMessage = "Gender is too long")]
        public string Gender { get; set; }
        [Column("IsActive")]
        public Boolean IsActive { get; set; }
        [Column("Creation Date")]
        public DateTime? CreationDate { get; set; }
        [Column("Created By")]
        public string? CreatedBy { get; set; }
        [Column("Last Modified By")]
        public string? ModifiedBy { get; set; }
        [Column("Last Modified Date")]
        public DateTime? ModifiedDate { get; set; }
    }
}
