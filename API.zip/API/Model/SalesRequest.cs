﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace angulartask.Model
{
    public class SalesRequest
    {
        public int Id { get; set; }
        [Required]
        public string CustomerCode { get; set; }

        [Required]
        public DateTime OrderDate { get; set; }
        [Required]
        public long TotalAmount { get; set; }
        [Required]
        public string Currency { get; set; }
        [Required]
        public string SalesStatus { get; set; }

        [Required]
        public string ProductCode { get; set; }
        [Required]
        public string Description { get; set; }
        [Required] 
        public string UOM { get; set; }
        [Required]
        public int Quantity { get; set; }
        [Required]
        public int UnitPrice { get; set; }
        [Required] 
        public long LineTotal { get; set; }
        public string? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

    }
}
