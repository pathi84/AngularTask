﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace angulartask.Model
{
    public class SalesResponse
    {
        public int Id { get; set; }
        public string CustomerCode { get; set; }

        public DateTime OrderDate { get; set; }
        public long TotalAmount { get; set; }
        public string Currency { get; set; }
        public string SalesStatus { get; set; }

        public string ProductCode { get; set; }
        public string Description { get; set; }
        public string UOM { get; set; }
        public int Quantity { get; set; }
        public int UnitPrice { get; set; }
        public long LineTotal { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }

    }
}
