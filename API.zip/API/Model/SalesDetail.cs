﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace angulartask.Model
{
    public class SalesDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("LineId")]
        public int Id { get; set; }
        public int SalesHeaderId { get; set; }

        [ForeignKey("SalesHeaderId")]   // if not specifed, Order_Id column will be used
        public SalesHeader SalesHeader { get; set; }

        [Required]
        [MaxLength(50, ErrorMessage = "ProductCode is too long")]
        [Column("ProductCode")]
        public string ProductCode { get; set; }

        [Required]
        [MaxLength(500, ErrorMessage = "Description is too long")]
        [Column("Description")]
        public string Description { get; set; }

        [Required]
        [MaxLength(50, ErrorMessage = "UOM is too long")]
        [Column("UOM")]
        public string UOM { get; set; }

        [Required]
        [Column("Quantity")]
        public int Quantity { get; set; }

        [Required]
        [Column("UnitPrice")]
        public int UnitPrice { get; set; }

        [Required]
        [Column("LineTotal")]
        public long LineTotal { get; set; }

        [Column("Created By")]
        public string? CreatedBy { get; set; }

        [Column("Created Date")]
        public DateTime? CreatedDate { get; set; }

    }
}
