﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace angulartask.Model
{
    public class SalesHeader
    {
        [Key]
        [Column("Id")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        [MaxLength(50, ErrorMessage = "CustomerCode is too long")]
        [Column("CustomerCode")]
        public string CustomerCode { get; set; }

        [Column("Order Date")]
        public DateTime OrderDate { get; set; }
        [Column("TotalAmount")]
        [Required]
        public long TotalAmount { get; set; }
        [Column("Currency")]
        public string Currency { get; set; }
        [Column("SalesStatus")]
        public string SalesStatus { get; set; }
        [Column("Created By")]
        public string? CreatedBy { get; set; }

        [Column("Created Date")]
        public DateTime? CreatedDate { get; set; }

        public SalesDetail SalesDetail { get; set; }
    }
}
