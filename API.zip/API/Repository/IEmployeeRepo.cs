﻿using angulartask.Model;

namespace angulartask.Repository
{
    public interface IEmployeeRepository
    {
        Employee Create(Employee employee);

        IEnumerable<Employee> Read();

        Employee Update(Employee employee, int Id);

        void Delete(int Id);
    }
}
