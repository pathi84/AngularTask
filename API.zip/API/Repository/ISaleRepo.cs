﻿using angulartask.Model;

namespace angulartask.Repository
{
    public interface ISaleRepository
    {
        void Create(SalesRequest saleRequest);

        IEnumerable<SalesResponse> Read();

        void Update(SalesRequest saleRequest, int Id);

        void Delete(int Id);
    }
}
