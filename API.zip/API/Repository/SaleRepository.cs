﻿using angulartask.Context;
using angulartask.Model;
using Microsoft.EntityFrameworkCore;

namespace angulartask.Repository
{
    public class SaleRepository : ISaleRepository
    {
        private readonly DatabaseContext saleContext;

        public SaleRepository(DatabaseContext _saleContext)
        {
            this.saleContext = _saleContext;
        }

        public void Create(SalesRequest saleRequest)
        {
            SalesHeader saleHeader = new SalesHeader();
            {
                saleHeader.CustomerCode = saleRequest.CustomerCode;
                saleHeader.OrderDate = saleRequest.OrderDate;
                saleHeader.Currency = saleRequest.Currency;
                saleHeader.TotalAmount = saleRequest.TotalAmount;
                saleHeader.SalesStatus = saleRequest.SalesStatus;
                saleHeader.CreatedBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                saleHeader.CreatedDate = DateTime.Now;
            }
            var response = saleContext.Add(saleHeader);
            saleContext.SaveChanges();
            int saleHeaderId = response.Entity.Id;

            SalesDetail saleDetail = new SalesDetail();
            {
                saleDetail.ProductCode = saleRequest.ProductCode;
                saleDetail.SalesHeaderId = saleHeaderId;
                saleDetail.Description = saleRequest.Description;
                saleDetail.UOM = saleRequest.UOM;
                saleDetail.LineTotal = saleRequest.LineTotal;
                saleDetail.UnitPrice = saleRequest.UnitPrice;
                saleDetail.Quantity = saleRequest.Quantity;
                saleDetail.CreatedBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                saleDetail.CreatedDate = DateTime.Now;
            }
            
            var detailResponse = saleContext.Add(saleDetail);
            saleContext.SaveChanges();
        }

        public void Delete(int Id)
        {
            var saleDetail = saleContext.SalesDetails.FirstOrDefault(x => x.Id == Id);
            var saleHeader = saleContext.SalesHeaders.Find(saleDetail.SalesHeaderId);
            saleContext.Remove(saleDetail);
            saleContext.SaveChanges();

            saleContext.Remove(saleHeader);
            saleContext.SaveChanges();
        }
        
        public IEnumerable<SalesResponse> Read()
        {
            var query = from detail in saleContext.Set<SalesDetail>()
                        join header in saleContext.Set<SalesHeader>()
                            on detail.SalesHeaderId equals header.Id
                        select new SalesResponse
                        {
                            Id = detail.Id,
                            ProductCode = detail.ProductCode,
                            Description = detail.Description,
                            UOM = detail.UOM,
                            LineTotal = detail.LineTotal,
                            UnitPrice = detail.UnitPrice,
                            Quantity = detail.Quantity,
                            CreatedBy = detail.CreatedBy,
                            CreatedDate = detail.CreatedDate,
                            CustomerCode = header.CustomerCode,
                            OrderDate = header.OrderDate,
                            Currency = header.Currency,
                            TotalAmount = header.TotalAmount,
                            SalesStatus = header.SalesStatus
                        };

            return query.ToList();
        }

        public void Update(SalesRequest saleRequest, int Id)
        {

            var saleDetail = saleContext.SalesDetails.Find(Id);
            {
                saleDetail.ProductCode = saleRequest.ProductCode;
                saleDetail.Description = saleRequest.Description;
                saleDetail.UOM = saleRequest.UOM;
                saleDetail.LineTotal = saleRequest.LineTotal;
                saleDetail.UnitPrice = saleRequest.UnitPrice;
                saleDetail.Quantity = saleRequest.Quantity;
            }
            var response = saleContext.Update(saleDetail);
            saleContext.SaveChanges();

            var saleHeader =saleContext.SalesHeaders.Find(saleDetail.SalesHeaderId);
            {
                saleHeader.CustomerCode = saleRequest.CustomerCode;
                saleHeader.OrderDate = saleRequest.OrderDate;
                saleHeader.Currency = saleRequest.Currency;
                saleHeader.TotalAmount = saleRequest.TotalAmount;
                saleHeader.SalesStatus = saleRequest.SalesStatus;
            }

            saleContext.Update(saleHeader);
            saleContext.SaveChanges();

        }
    }
}
