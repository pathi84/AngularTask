﻿using angulartask.Context;
using angulartask.Model;

namespace angulartask.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly DatabaseContext employeeContext;

        public EmployeeRepository(DatabaseContext employeeContext)
        {
            this.employeeContext = employeeContext;
        }

        public Employee Create(Employee employee)
        {
            employee.CreatedBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            employee.CreationDate = DateTime.Now;
            var response = employeeContext.Add(employee);
            employeeContext.SaveChanges();
            return response.Entity;
        }

        public void Delete(int Id)
        {
            var employee = employeeContext.Employees.FirstOrDefault(x => x.Id == Id);
            employeeContext.Remove(employee);
            employeeContext.SaveChanges();
        }

        public IEnumerable<Employee> Read()
        {
            return employeeContext.Employees.ToList();
        }

        public Employee Update(Employee employee, int Id)
        {
            var _employee = employeeContext.Employees.Find(Id);
            {
                _employee.Name = employee.Name;
                _employee.Title = employee.Title;
                _employee.Department = employee.Department;
                _employee.Country = employee.Country;
                _employee.Gender = employee.Gender;
                _employee.JoiningDate = employee.JoiningDate;
                _employee.IsActive = employee.IsActive;
                _employee.ModifiedBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                _employee.ModifiedDate = DateTime.Now;
            }

            var response = employeeContext.Update(_employee);
            employeeContext.SaveChanges();
            return response.Entity;
        }
    }
}
