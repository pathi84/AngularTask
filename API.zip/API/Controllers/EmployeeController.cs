﻿using angulartask.Model;
using angulartask.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace angulartask.Controllers
{
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        IEmployeeRepository employeeRepository;
        private readonly ILogger<EmployeeController> _logger;


        public EmployeeController(ILogger<EmployeeController> logger, IEmployeeRepository _employeeRepository)
        {
            _logger = logger;
            employeeRepository = _employeeRepository;
        }

        // GET: EmployeeController
        [HttpGet]
        public IActionResult GetEmployees()
        {
            return Ok(employeeRepository.Read());
        }

        // GET: EmployeeController/Create
        [HttpPost]
        public IActionResult Create([FromBody] Employee employee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    return Ok(employeeRepository.Create(employee));
                }
                catch (Exception e)
                {
                    return ErrorResult(e);
                }
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("UpdateEmployee/{Id:int}")]
        public IActionResult Update([FromBody] Employee employee, int Id)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    return Ok(employeeRepository.Update(employee,Id));
                }
                catch (Exception e)
                {
                    return ErrorResult(e);
                }
            }
            else { return BadRequest(); }
        }

        [HttpDelete]
        [Route("DeleteEmployee/{Id:int}")]
        public IActionResult DeleteUser(int Id)
        {
            try
            {
                employeeRepository.Delete(Id);
                return Ok();
            }
            catch (Exception e)
            {
                return ErrorResult(e);
            }
        }



        private ObjectResult ErrorResult(Exception ex)
        {
            _logger.LogError(ex, nameof(EmployeeController));
            var errorObjectResult = new ObjectResult("Internal Server error");
            errorObjectResult.StatusCode = StatusCodes.Status500InternalServerError;
            return errorObjectResult;
        }

    }
}
