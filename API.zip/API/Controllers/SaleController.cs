﻿using angulartask.Model;
using angulartask.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace angulartask.Controllers
{
    [Route("api/[controller]")]
    public class SaleController : ControllerBase
    {
        ISaleRepository saleRepository;
        private readonly ILogger<SaleController> _logger;


        public SaleController(ILogger<SaleController> logger, ISaleRepository _saleRepository)
        {
            _logger = logger;
            saleRepository = _saleRepository;
        }

        // GET: SaleController
        [HttpGet]
        public IActionResult GetSales()
        {
            return Ok(saleRepository.Read());
        }

        // GET: EmployeeController/Create
        [HttpPost]
        public IActionResult Create([FromBody] SalesRequest saleRequest)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    saleRepository.Create(saleRequest);
                    return Ok();
                }
                catch (Exception e)
                {
                    return ErrorResult(e);
                }
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("UpdateSale/{Id:int}")]
        public IActionResult Update([FromBody] SalesRequest saleRequest, int Id)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    saleRepository.Update(saleRequest, Id);
                    return Ok();
                }
                catch (Exception e)
                {
                    return ErrorResult(e);
                }
            }
            else { return BadRequest(); }
        }

        [HttpDelete]
        [Route("DeleteSale/{Id:int}")]
        public IActionResult DeleteUser(int Id)
        {
            try
            {
                saleRepository.Delete(Id);
                return Ok();
            }
            catch (Exception e)
            {
                return ErrorResult(e);
            }
        }



        private ObjectResult ErrorResult(Exception ex)
        {
            _logger.LogError(ex, nameof(SaleController));
            var errorObjectResult = new ObjectResult("Internal Server error");
            errorObjectResult.StatusCode = StatusCodes.Status500InternalServerError;
            return errorObjectResult;
        }

    }
}
