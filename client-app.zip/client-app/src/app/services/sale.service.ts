import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class SaleService {
  constructor(private _http: HttpClient) {}

  addSale(data: any): Observable<any> {
    return this._http.post(environment.saleapiendpoint, data);
  }

  updateSale(id: number, data: any): Observable<any> {
    return this._http.put(`${environment.saleapiendpoint}UpdateSale/${id}`, data);
  }

  getSaleList(): Observable<any> {
    return this._http.get(environment.saleapiendpoint);
  }

  deleteSale(id: number): Observable<any> {
    return this._http.delete(`${environment.saleapiendpoint}DeleteSale/${id}`);
  }
}
