import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  constructor(private _http: HttpClient) {}

  addEmployee(data: any): Observable<any> {
    return this._http.post(environment.apiendpoint, data);
  }

  updateEmployee(id: number, data: any): Observable<any> {
    return this._http.put(`${environment.apiendpoint}UpdateEmployee/${id}`, data);
  }

  getEmployeeList(): Observable<any> {
    return this._http.get(environment.apiendpoint);
  }

  deleteEmployee(id: number): Observable<any> {
    return this._http.delete(`${environment.apiendpoint}DeleteEmployee/${id}`);
  }
}
