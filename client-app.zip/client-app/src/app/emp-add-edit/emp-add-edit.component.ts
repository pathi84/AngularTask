import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CoreService } from '../core/core.service';
import { EmployeeService } from '../services/employee.service';
import { SubSink } from 'subsink';

@Component({
  selector: 'app-emp-add-edit',
  templateUrl: './emp-add-edit.component.html',
  styleUrls: ['./emp-add-edit.component.scss'],
})
export class EmpAddEditComponent implements OnInit, OnDestroy {
  private subSink = new SubSink();
  empForm: FormGroup;
  country: string[] = [
    'Saudi Arabia',
    'India',
    'UK',
    'USA',
    'UAE',
  ];

  department: string[] = [
    'Admin',
    'HR',
    'IT Infra',
    'Development',
  ];

  constructor(
    private _fb: FormBuilder,
    private _empService: EmployeeService,
    private _dialogRef: MatDialogRef<EmpAddEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _coreService: CoreService
  ) {
    this.empForm = this._fb.group({
      name: ['',Validators.required],
      title: ['',Validators.required],
      department: ['',Validators.required],
      country: ['',Validators.required],
      joiningDate: ['',Validators.required],
      gender: ['',Validators.required],
      isActive: ['',Validators.required],
    });
  }

  ngOnInit(): void {
    this.empForm.patchValue(this.data);
  }

  onFormSubmit() {
    console.log(this.data)
    if (this.empForm.valid) {
      if (this.data) {
        this.subSink.add(this._empService
          .updateEmployee(this.data.id, this.empForm.value)
          .subscribe({
            next: (val: any) => {
              this._coreService.openSnackBar('Employee detail updated!');
              this._dialogRef.close(true);
            },
            error: (err: any) => {
              console.error(err);
            },
          }));
      } else {
        this.subSink.add(this._empService.addEmployee(this.empForm.value).subscribe({
          next: (val: any) => {
            this._coreService.openSnackBar('Employee added successfully');
            this._dialogRef.close(true);
          },
          error: (err: any) => {
            console.error(err);
          },
        }));
      }
    }
  }

  ngOnDestroy(): void {
    this.subSink.unsubscribe();
  }
}
