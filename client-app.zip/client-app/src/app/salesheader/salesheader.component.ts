import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { CoreService } from '../core/core.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SaleService } from '../services/sale.service';
import { SubSink } from 'subsink';

@Component({
  selector: 'app-salesheader',
  templateUrl: './salesheader.component.html',
  styleUrls: ['./salesheader.component.scss'],
})
export class SalesHeaderComponent implements OnInit, OnDestroy {
  private subSink = new SubSink();
  @ViewChild('ngFormDirective', { static: false }) ngFormDirective!: NgForm;
  saleForm: FormGroup;
  private data: any
  isFormSubmit:Boolean= true;
  submitted=false;

  country: string[] = [
    'Saudi Arabia',
    'India',
    'UK',
    'USA',
    'UAE',
  ];
  displayedColumns: string[] = [
    'id',
    'customerCode',
    'orderDate',
    'totalAmount',
    'currency',
    'salesStatus',
    'productCode',
    'uom',
    'quantity',
    'unitPrice',
    'lineTotal',
    'description',
    'createdDate',
    'createdBy',
    'action',
  ];
  salesstatus: string[] = [
    'Procurement',
    'Open',
    'Processed',
    'Completed',
  ];

  currencies: string[] = [
    'SAR',
    'INR',
    'USD',
    'EUR'
  ]

  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  
  constructor(
    private _fb: FormBuilder,
    private _saleService: SaleService,
    private _coreService: CoreService
  ) {
    this.saleForm = this._fb.group({
      customerCode: ['',Validators.required],
      orderDate: ['',Validators.required],
      totalAmount: ['',Validators.required,],
      currency: ['',Validators.required],
      salesStatus: ['',Validators.required],
      productCode: ['',Validators.required],
      uom: ['',Validators.required],
      quantity: ['',Validators.required],
      unitPrice: ['',Validators.required],
      lineTotal: ['',Validators.required],
      description:['',Validators.required]
    });
  }

  ngOnInit(): void {
    this.getSaleList();
  }

  getSaleList() {
    this.subSink.add(this._saleService.getSaleList().subscribe({
      next: (res) => {
        console.log(res)
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      },
      error: console.log,
    }));
  }

  onFormSubmit() {
    this.submitted = true;
    if(!this.isFormSubmit) 
    {
      this.isFormSubmit = true;
      return;
    }
    if (this.saleForm.valid) {
      if (this.data) {
        this.subSink.add(this._saleService
          .updateSale(this.data.id, this.saleForm.value)
          .subscribe({
            next: (val: any) => {
              this._coreService.openSnackBar('Sale detail updated!');
              this.data = '';
              this.saleForm.reset();
              this.ngFormDirective?.resetForm();
              this.submitted = false;
              this.getSaleList();
            },
            error: (err: any) => {
              console.error(err);
            },
          }));
      } else {
          this.subSink.add(this._saleService.addSale(this.saleForm.value).subscribe({
            next: (val: any) => {
              this._coreService.openSnackBar('Sale added successfully');
              this.data = '';
              this.saleForm.reset();
              this.ngFormDirective?.resetForm();
              this.submitted = false;
              this.getSaleList();
            },
            error: (err: any) => {
              console.error(err);
            },
          }));
        
      }
      
    }
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteEmployee(id: number) {
    this.isFormSubmit = false;
    this.subSink.add(this._saleService.deleteSale(id).subscribe({
      next: (res) => {
        this.ngFormDirective?.resetForm();
        this._coreService.openSnackBar('Sale deleted!', 'done');
        this.getSaleList();
      },
      error: console.log,
    }));
  }

  openEditForm(data: any) {
      this.isFormSubmit = false;
      this.data = data;
      this.saleForm.patchValue(data);
  }

  ngOnDestroy(): void {
    this.subSink.unsubscribe();
  }
}
