export const environment = {
    production: false,
    apiendpoint: 'http://localhost:5239/api/employee/',
    saleapiendpoint: 'http://localhost:5239/api/sale/'
  };